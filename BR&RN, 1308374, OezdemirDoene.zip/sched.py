
####################################################################################################

import sys # Einbinden für sys.argv-Kommandozeilenargumente
import copy # Einbinden für deepcopy bei Listen
import os.path # Einbinden für exists(), dirname() und weitere

####################################################################################################
# Ausgabe von Fehlern und Hinweisen                                                                #
####################################################################################################

def error(type):
  # Fehlermeldung mit roter Formatierung im Terminal ausgeben
  print('\x1b[1;31m[ERROR]\x1b[0m {}'.format(type))
  quit(-1) # Skript terminieren

def info(type):
  # Hinweis mit gelber Formatierung im Terminal ausgeben
  print('\x1b[1;33m[INFO]\x1b[0m {}'.format(type))

####################################################################################################
# Dateieingabe und -ausgabe                                                                        #
####################################################################################################

def io(path, rw, data):
  # Lesen einer Datei
  if(rw == 'r'): # Falls Variable rw gleich r ist, lesen
    with open(path, 'r', encoding = 'utf-8') as file: # Datei lesend öffnen
      data.clear() # Datenliste leeren
      # Zeilenweise lesen und nur Zeilen mit drei Zahlenwerten parsen
      for line in file.readlines(): # Über Zeilen iterieren
        if(len(line.split(' ')) == 3 and line[0].isnumeric()): # Falls Format der Zeile stimmt
          # v0 = Prozessnr. / v1 = Anfragezeitpunkt / v2 = Rechenzeit
          v0 = int(line.split(' ')[0]) # Prozessnummer einlesen
          v1 = int(line.split(' ')[1]) # Anfragezeitpunkt einlesen
          v2 = int(line.split(' ')[2]) # Rechenzeit einlesen
          data.append([v0, v1, v2]) # Daten in Liste anhängen
    # Fehlermeldung, falls keine Werte eingelesen wurden
    if(not data): # Falls Datenliste leer
      error('no process found') # Fehlermeldung ausgeben, Skript terminieren

  # Schreiben einer Datei
  if(rw == 'w'): # Falls Variable rw gleich w ist, schreiben
    with open(path, 'w', encoding = 'utf-8') as file: # Datei schreibend öffnen
      for line in data: # Über Zeilen iterieren
        file.write('{}\n'.format(line)) # In Datei zeilenweise schreiben

####################################################################################################
# Formatieren der Prozessliste und Metriken                                                        #
####################################################################################################

def prnt(data, style, plain):
  # Puffer erstellen und je nach Parameter ANSI-Farbsequenzen nutzen
  if(plain): # Sollte Variable plain ungleich 0 sein
    # Leeren Puffer anlegen, Formatierungsliste f mit leeren Elementen initialisieren
    p, f = [], ['', '', '']
  else: # Andernfalls
    # Leeren Puffer anlegen, ANSI-Escapesequenzen in Liste f einfügen
    p, f = [], ['\x1b[0m', '\x1b[1m', '\x1b[1;33m']

  # Prozesse als Block formatieren
  if(style == 'b'): # Falls Variable style gleich b ist
    for n, l in enumerate(data): # Über Datenliste iterieren mit n und l
      # Erster Prozess
      if(n == 0): # Falls Index bei nulltem Element liegt
        # Anfangszeitpunkt formatiert in Puffer einfügen
        p.append('┏━━━━┓ ❮ {}{:0>3}{}'.format(f[1], l[1], f[0]))
        # Prozessnummer formatiert in Puffer einfügen
        p.append('┃ {}{:0>2}{} ┃'.format(f[2], l[0], f[0]))
        # Zeitpunkt formatiert in Puffer einfügen
        p.append('┣━━━━┫ ❮ {}{:0>3}{}'.format(f[1], l[2], f[0]))
      # Letzter Prozess (möglicher vorheriger Leerlauf wird berücksichtigt)
      elif(n == len(data)-1): # Sonst falls Index bei Länge der Datenliste - 1 liegt
        if(data[n-1][2] != l[1]): # Falls Leerlauf vorkommt
          # Leerlauf formatiert in Puffer einfügen
          p.append('┃ {}..{} ┃'.format(f[2], f[0]))
          # Zeitpunkt formatiert in Puffer einfügen
          p.append('┣━━━━┫ ❮ {}{:0>3}{}'.format(f[1], l[1], f[0]))
        # Prozessnummer formatiert in Puffer einfügen
        p.append('┃ {}{:0>2}{} ┃'.format(f[2], l[0], f[0]))
        # Endzeitpunkt formatiert in Puffer einfügen
        p.append('┗━━━━┛ ❮ {}{:0>3}{}'.format(f[1], l[2], f[0]))
        ## Leerzeile in Puffer einfügen
        p.append('')
      # Alle Prozesse dazwischen (möglicher vorheriger Leerlauf wird berücksichtigt)
      else: # Andernfalls folgende Anweisungen
        if(data[n-1][2] != l[1]): # Falls Leerlauf vorkommt
          # Leerlauf formatiert in Puffer einfügen
          p.append('┃ {}..{} ┃'.format(f[2], f[0]))
          # Zeitpunkt formatiert in Puffer einfügen
          p.append('┣━━━━┫ ❮ {}{:0>3}{}'.format(f[1], l[1], f[0]))
        # Prozessnummer formatiert in Puffer einfügen
        p.append('┃ {}{:0>2}{} ┃'.format(f[2], l[0], f[0]))
        # Zeitpunkt formatiert in Puffer einfügen
        p.append('┣━━━━┫ ❮ {}{:0>3}{}'.format(f[1], l[2], f[0]))

  # Prozesse in kompakter Darstellung formatieren
  if(style == 's'): # Falls Variable style gleich s ist
    # Über Liste iterieren und jeweils Prozessnummer (Beginn-Ende) hinzufügen
    for i in data: # Über Datenliste iterieren
      # Formatiert in Puffer einfügen
      p.append('ᐳ {:0>2} ({:0>3}-{:0>3})'.format(i[0], i[1], i[2]))

  # Metriken als Tabelle formatieren
  if(style == 'm'): # Falls Variable style gleich m ist
    for n, l in enumerate(data): # Über Datenliste iterieren mit n und l
      # Durchschnittswert zwischenspeichern, Tabellenkopf erzeugen
      if(n == 0): # Falls n bei nulltem Index liegt
        z = l[1], l[2] # Liste mit durchschnittlichen Metrikenwerten
        p.append('┏━━━━┯━━━━━━━━━━┯━━━━━━━━━━━┓') # Rahmenelemente dem Puffer anhängen
        # Werte formatiert einfügen
        p.append('┃ {}PN │ Laufzeit │ Wartezeit{} ┃'.format(f[1], f[0]))
        p.append('┠────┼──────────┼───────────┨') # Rahmenelemente dem Puffer anhängen
      # Werte zu den einzelnen Prozessen einfügen
      else: # Andernfalls folgendes Vorgehen
        # Werte formatiert einfügen
        p.append('┃ {:0>2} │     {:>4} │      {:>4} ┃'.format(l[0], l[1], l[2]))
      # Tabellenende erzeugen, Durchschnittswerte einfügen
      if(n == len(data)-1): # Falls n bei Länge der Datenliste - 1 liegt:
        p.append('┠────┼──────────┼───────────┨') # Rahmenelemente dem Puffer anhängen
        # Durchschnittliche Metrikenwerte formatiert einfügen
        p.append('┃ {}ø  │ {:>8.2f} │ {:>9.2f}{} ┃'.format(f[1], z[0], z[1], f[0]))
        p.append('┗━━━━┷━━━━━━━━━━┷━━━━━━━━━━━┛') # Rahmenelemente dem Puffer anhängen

  # Rückgabe des Puffers
  return p

####################################################################################################
# Zeitablaufsteuerung - First Come First Served (FCFS)                                             #
####################################################################################################

def fcfs(list):
  # Prozessnr. | Anfragezeitpunkt | Rechenzeit   [geordnete Prozessanfragen]
  proc = sorted(copy.deepcopy(list), key = lambda tup:tup[1])
  # Prozessnr. | Anfragezeitpunkt | Restzeit     [Warteschleife]
  fifo = []
  # Prozessnr. | Ausführstart     | Ausführende  [auszuführende Prozesse]
  exec = []
  # Prozessnr. | Laufzeit         | Wartezeit    [Metriken]
  metr = []

  # Rechenzeit zum späteren Ermitteln der Metriken kopieren
  for i in sorted(proc): # Über geordnete Prozessanfrageliste iterieren
    metr.append([i[0], 0, i[2]]) # Elemente in Metrikenliste übernehmen

  # Allokation durchführen, bis alle Prozesse zugeordnet sind
  while(1):
    # Warteschleife, falls leer, erneut befüllen (kann Leerlaufphase erzeugen)
    if(not fifo and proc): # Falls Warteschleife leer und Prozessanfrageliste nicht leer
      fifo.append(proc[0]) # Anhängen an Warteschleife
      time = proc[0][1] # Zeit auf Element 1 in Prozessanfrageliste 0 setzen
      proc.pop(0) # Prozess aus Prozessanfrageliste entfernen
    # Allokation beenden, wenn Prozessanfrageliste und Warteschleife leer sind
    elif(not fifo): # Andernfalls, wenn Warteschleife leer
      break # Allokationsschleife verlassen

    # Rechenzeit zuweisen, Ausführung bei Bedarf auf späteres Zeitintervall schieben
    exec.append([fifo[0][0], time, time + fifo[0][2]]) # Prozessanfrageliste erweitern
    time += fifo[0][2] # Zeitwert inkremieren
    i = fifo[0][0] - 1 # Index für Metrikenliste ermitteln
    metr[i][1] = time - fifo[0][1] # Laufzeit schreiben
    metr[i][2] = metr[i][1] - metr[i][2] # Wartezeit schreiben
    fifo.pop(0) # Prozess aus Warteschleife entfernen

    # Bei passender Ankunftszeit werden Prozesse in die Warteschleife übernommen
    while(proc and proc[0][1] <= time): # Schleife, solange Zeitverhältnisse passen
      fifo.append(proc[0]) # Prozess in Warteschleife anhängen
      proc.pop(0) # Prozess aus Prozessanfrageliste entfernen

  # Mittelwert für Metriken bilden und bei Index 0 speichern
  metr.insert(0, [0, 0, 0]) # Listenelement mit Index 0 einfügen

  for i in range(1, len(metr)): # Über Metrikenliste iterieren
    metr[0][1] += metr[i][1] / (len(metr) - 1) # mittlere Laufzeit errechnen
    metr[0][2] += metr[i][2] / (len(metr) - 1) # mittlere Wartezeit errechnen

  # Rückgabe von der Ausführungsliste sowie Metriken
  return exec, metr

####################################################################################################
# Zeitablaufsteuerung - Round Robin (RR)                                                           #
####################################################################################################

def rr(list, quantum):
  # Prozessnr. | Anfragezeitpunkt | Rechenzeit   [geordnete Prozessanfragen]
  proc = sorted(copy.deepcopy(list), key = lambda tup:tup[1])
  # Prozessnr. | Anfragezeitpunkt | Restzeit     [Warteschleife]
  fifo = []
  # Prozessnr. | Ausführstart     | Ausführende  [auszuführende Prozesse]
  exec = []
  # Prozessnr. | Laufzeit         | Wartezeit    [Metriken]
  metr = []

  # Rechenzeit zum späteren Ermitteln der Metriken kopieren
  for i in sorted(proc): # Über geordnete Prozessanfrageliste iterieren
    metr.append([i[0], 0, i[2]]) # Elemente in Metrikenliste übernehmen

  # Allokation durchführen, bis alle Prozesse zugeordnet sind
  while(1):
    # Warteschleife, falls leer, erneut befüllen (kann Leerlaufphase erzeugen)
    if(not fifo and proc): # Falls Warteschleife leer und Prozessanfrageliste nicht leer
      fifo.append(proc[0]) # Anhängen an Warteschleife
      time = proc[0][1] # Zeit auf Element 1 in Prozessanfrageliste 0 setzen
      proc.pop(0) # Prozess aus Prozessanfrageliste entfernen
    # Allokation beenden, wenn Prozessanfrageliste und Warteschleife leer sind
    elif(not fifo): # Andernfalls, wenn Warteschleife leer
      break # Allokationsschleife verlassen

    # Unterscheidung, angeforderte Rechenzeit ">" oder "<" bzw. "=" Zeitquantum
    if(fifo[0][2] > quantum): # Fals Zeitquantum überschritten
      # Prozess erhält einen Teil der Rechenzeit und kommt in die Warteschleife
      exec.append([fifo[0][0], time, time + quantum]) # Prozessanfrageliste erweitern
      time += quantum # Zeit inkremieren
      fifo[0][2] -= quantum # Rechenzeitdekrement in Warteschleife
      shift = 1 # Shift auf 1 setzen
    else: # Andernfalls folgendes Vorgehen
      # Prozess wird innerhalb von einem Zeitschlitz abgeschlossen
      exec.append([fifo[0][0], time, time + fifo[0][2]]) # Prozessanfrageliste erweitern
      time += fifo[0][2] # Zeit inkremieren
      i = fifo[0][0] - 1 # Index für Metrikenliste ermitteln
      metr[i][1] = time - fifo[0][1] # Laufzeit schreiben
      metr[i][2] = metr[i][1] - metr[i][2] # Wartezeit schreiben
      fifo.pop(0) # Prozess aus Warteschleife entfernen
      shift = 0 # Shift auf 0 setzen

    # Bei passender Ankunftszeit werden Prozesse in die Warteschleife übernommen
    while(proc and proc[0][1] <= time): # Schleife, solange Zeitverhältnisse passen
      fifo.append(proc[0]) # Prozess in Warteschleife anhängen
      proc.pop(0) # Prozess aus Prozessanfrageliste entfernen

    # Der zuletzt ausgeführte Prozess wird an das Ende der Warteschleife verschoben
    if(shift): # Falls shift-Variable ungleich 0
      fifo = fifo[1:] + fifo[0:1] # Slicing-Operator bei Warteschleife anwenden

  # Mittelwert für Metriken bilden und bei Index 0 speichern
  metr.insert(0, [0, 0, 0]) # Listenelement mit Index 0 einfügen

  for i in range(1, len(metr)): # Über Metrikenliste iterieren
    metr[0][1] += metr[i][1] / (len(metr) - 1) # mittlere Laufzeit errechnen
    metr[0][2] += metr[i][2] / (len(metr) - 1) # mittlere Wartezeit errechnen

  # Rückgabe von der Ausführungsliste sowie Metriken
  return exec, metr

####################################################################################################
# Hauptfunktion                                                                                    #
####################################################################################################

def main():
  # Verschiedene Listen und Variablen deklarieren und initialisieren
  # Eingabe, Ausgabe, Zwischenspeicher (list), Ausgabepuffer (b), alle leer initialisieren
  input, output, list, b = '', '', [], []
  # Variable für Zeitquantum, Standardwert 5 und vier Switch-Variablen mit dem Wert 0
  quantum, s0, s1, s2, s3 = 5, 0, 0, 0, 0

  # Über die übergebenen Kommandozeilenparameter iterieren
  for i in range(1,len(sys.argv)): # Mit Index i über sys.argv iterieren
    # Hilfe bzw. Ausgeben einer Parameterübersicht
    if(sys.argv[i] == "-help" or sys.argv[i] == "-h"): # Falls Hilfeparameter
      print(" -h | -help") # Eine Zeile in Terminal ausgeben
      print(" -i | -input {path}") # Eine Zeile in Terminal ausgeben
      print(" -o | -output {path}") # Eine Zeile in Terminal ausgeben
      print(" -q | -quantum {#}") # Eine Zeile in Terminal ausgeben
      print(" -s | -strategy {FCFS, RR}") # Eine Zeile in Terminal ausgeben
      quit(0) # Skript terminieren

    # Auswahl der Eingabedatei
    elif(sys.argv[i] == "-input" or sys.argv[i] == "-i"): # Falls Inputparameter
      if(i+1 < len(sys.argv)): # Falls weiteres Element in Argumentliste vorhanden
        if(os.path.isfile(sys.argv[i+1])): # Falls Eingabedatei auffindbar
          input = sys.argv[i+1] # In input übernehmen
        else: # Andernfalls, wenn nicht auffindbar
          error('file does not exist') # Fehlermeldung ausgeben und Skript terminieren
      else: # Andernfalls, kein darauffolgendes Element vorhanden
        error('missing path') # Fehlermeldung ausgeben und Skript terminieren

    # Auswahl einer Ausgabedatei
    elif(sys.argv[i] == "-output" or sys.argv[i] == "-o"): # Falls Outputparameter
      if(i+1 < len(sys.argv)): # Falls weiteres Element in Argumentliste vorhanden
        # Falls weiteres Element ein Pfad ist und dieser Pfad im Dateisystem existiert
        if(os.path.exists(os.path.dirname(sys.argv[i+1]))):
          output = sys.argv[i+1] # In output übernehmen
          s3 = 1 # Switchvariable 3 auf eins setzen
        else: # Andernfalls, wenn nicht existent
          error('directory does not exist') # Fehlermeldung ausgeben und Skript terminieren
      else: # Andernfalls, kein darauffolgendes Element vorhanden
        error('missing path') # Fehlermeldung ausgeben und Skript terminieren

    # Festlegen eines Zeitquantums für RR
    elif(sys.argv[i] == "-quantum" or sys.argv[i] == "-q"): # Falls Zeitquantumparameter
      if(i+1 < len(sys.argv)): # Falls weiteres Element in Argumentliste vorhanden
        if(sys.argv[i+1].isnumeric()): # Falls das Element numerisch ist
          quantum = int(sys.argv[i+1]) # Zeitquantum übernehmen
          s0 = 1 # Switchvariable 0 auf eins setzen
        else: # Bei nicht numerischem Wert
          error('value out of range') # Fehlermeldung ausgeben und Skript terminieren
      else: # Andernfalls, kein darauffolgendes Element vorhanden
        error('missing value') # Fehlermeldung ausgeben und Skript terminieren

    # Auswahl des Verfahrens (FCFS und/oder RR)
    elif(sys.argv[i] == "-strategy" or sys.argv[i] == "-s"): # Falls Strategieparameter
      if(i+1 < len(sys.argv)): # Falls weiteres Element in Argumentliste vorhanden
        if(sys.argv[i+1].upper() == "FCFS"): # Falls es FCFS ist
          s1 = 1 # Switchvariable 1 auf eins setzen
        elif(sys.argv[i+1].upper() == "RR"): # Falls es RR ist
          s2 = 1 # Switchvariable 2 auf eins setzen
        else: # Bei anderem Wert
          error('unknown strategy') # Fehlermeldung ausgeben und Skript terminieren
      else: # Andernfalls, kein darauffolgendes Element vorhanden
        error('missing value') # Fehlermeldung ausgeben und Skript terminieren

    # Fehlermeldung falls nicht auswertbar
    elif(sys.argv[i].startswith("-")): # Falls ein - enthalten, aber nicht auszuwerten
      error('unknown switch') # Fehlermeldung ausgeben und Skript terminieren

  # Prozessliste einlesen, falls FCFS oder RR ausgewählt wurde
  if(s1 or s2): # Falls Switchvariable 1 oder 2 nicht null sind
    # Standardwerte bei Prozessliste nehmen, falls keine Eingabedatei angegeben wurde
    if(not input): # Sollte keine Eingabedatei spezifiziert worden sein
      info('use default process list') # Hinweis ausgeben
      list = [[1, 0, 10], [2, 0, 15], [3, 5, 10]] # Standardliste verwenden
    else: # Ansonsten, wenn spezifiziert
      io(input, 'r', list) # Eingabedatei einlesen und in Liste übernehmen

  # Hinweis zu Standardwert ausgeben, falls RR gewählt und Quantum nicht spezifiziert
  if(not s0 and s2): # Sollte RR ausgewählt sein, aber kein Zeitquantum angegeben
    info('use default quantum') # Hinweis ausgeben

  # FCFS ausführen, falls ausgewählt
  if(s1): # Falls Switchvariable 1 ungleich 0
    exec, metr = fcfs(list) # Zeitablaufsteuerung ausführen, Ergebnisse in Liste übernehmen
    b += ['FCFS-Scheduling:\n'] # Eine Zeile im Puffer hinzufügen, Verfahren angeben
    b += prnt(exec, 'b', s3) # Prozessliste in Puffer formatiert einfügen
    b += prnt(metr, 'm', s3) # Metrikenliste in Puffer formatiert einfügen

  # Leerzeile in der Ausgabe hinzufügen, falls beide Verfahren angewendet werden
  if(s1 and s2): # Falls Switchvariable 1 und 2 ungleich null
    b += [''] # Leerzeile in Puffer hinzufügen

  # RR ausführen, falls ausgewählt
  if(s2): # Falls Switchvariable 2 ungleich 0
    exec, metr = rr(list, quantum) # Zeitablaufsteuerung ausführen, Ergebnisse in Liste übernehmen
    b += ['RR-Scheduling:\n'] # Eine Zeile im Puffer hinzufügen, Verfahren angeben
    b += prnt(exec, 'b', s3) # Prozessliste in Puffer formatiert einfügen
    b += prnt(metr, 'm', s3) # Metrikenliste in Puffer formatiert einfügen

  # Ausgabe in Terminal, falls keine Ausgabedatei festgelegt wurde
  if(s3): # Falls Switchvariable 3 ungleich null
    io(output, 'w', b) # Ausgabe des Puffers in die mit output spezifizierte Datei
  else: # Andernfalls, wenn output nicht spezifiziert
    [print(x) for x in b] # Ausgabe in das Terminal

main() # Einsprungpunkt im Skript festlegen, Hauptfunktion soll aufgerufen werden

####################################################################################################
